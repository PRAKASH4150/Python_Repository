#*****************************************************************
# Assignment 1
# Name: Sai Surya Prakash Moka 
# ID: 00834035
# Description: This python module prints "Hello World!" to STDOUT
#*****************************************************************
print("Hello World!")