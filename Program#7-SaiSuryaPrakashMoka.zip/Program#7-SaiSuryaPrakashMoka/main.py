#************************************************************************************************
# Name: Sai Surya Prakash Moka
# ID: 00834035
# Description: This file acts as a main file which calls the menu function present in the
# fnct.py module which is used to plot a graph for the expression ax^n+bx^(n-1)+.....c=f(x)
#************************************************************************************************
from fnct import menu #importing only menu function from fnct module

if __name__=="__main__":#code to call the menu() upon starting
    menu()